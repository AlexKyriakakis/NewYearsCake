
package newYearCake;


public class Recipe {
    
    
    String[] ingredients =new String[15] ;
    float cost;
    int calories;
    

    
}
