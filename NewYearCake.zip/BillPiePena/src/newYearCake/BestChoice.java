package newYearCake;

import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;


public class BestChoice {

    public BestChoice(final Recipe Rec1, final Recipe Rec2, final Recipe Rec3, final Recipe Rec4) {
        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
        try {
            DocumentBuilder builder = factory.newDocumentBuilder();
            Document doc = builder.parse("src/newYearCake/Recipes.xml");
            doc.normalize();
            NodeList recipeList = doc.getElementsByTagName("recipe");
            for (int i = 0; i < recipeList.getLength(); i++) {

                Node nNode = recipeList.item(i);
                Element eElement = (Element) nNode;

                if (nNode.getNodeType() == Node.ELEMENT_NODE) {

                    switch (i) {
                        case 0:
                            for (int k = 1; k <= 8; k++) {
                                Rec1.ingredients[k] = (eElement.getElementsByTagName("systatiko"+k).item(0).getTextContent());
                            }
                            Rec1.cost = Float.valueOf(eElement.getElementsByTagName("price").item(0).getTextContent());
                            Rec1.calories = Integer.valueOf(eElement.getElementsByTagName("calories").item(0).getTextContent());
                            break;
                        case 1:
                            for (int k = 1; k <= 8; k++) {
                                Rec2.ingredients[k] = (eElement.getElementsByTagName("systatiko"+k).item(0).getTextContent());
                            }
                            Rec2.cost = Float.valueOf(eElement.getElementsByTagName("price").item(0).getTextContent());
                            Rec2.calories = Integer.valueOf(eElement.getElementsByTagName("calories").item(0).getTextContent());
                            break;
                        case 2:
                            for (int k = 1; k <= 11; k++) {
                                Rec3.ingredients[k] = (eElement.getElementsByTagName("systatiko"+k).item(0).getTextContent());
                            }
                            Rec3.cost = Float.valueOf(eElement.getElementsByTagName("price").item(0).getTextContent());
                            Rec3.calories = Integer.valueOf(eElement.getElementsByTagName("calories").item(0).getTextContent());
                            break;
                        case 3:
                            for (int k = 1; k <= 7; k++) {
                                Rec4.ingredients[k] = (eElement.getElementsByTagName("systatiko"+k).item(0).getTextContent());
                            }
                            Rec4.cost = Float.valueOf(eElement.getElementsByTagName("price").item(0).getTextContent());
                            Rec4.calories = Integer.valueOf(eElement.getElementsByTagName("calories").item(0).getTextContent());
                            break;
                        default:
                            break;
                    }

                }
            }

        } catch (ParserConfigurationException | SAXException | IOException ex) {
            Logger.getLogger(Recipe.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

}
