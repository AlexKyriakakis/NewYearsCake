package newYearCake;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.Toolkit;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.data.general.DefaultPieDataset;

public class CakeIngredientsGUI {

    final JTextArea rec1Text = new JTextArea("\n                    NewYearCake 1\n\n");
    int r1 = 0;
    int r2 = 0;
    int r3 = 0;
    int r4 = 0;

    CakeIngredientsGUI(final Recipe Rec1, final Recipe Rec2, final Recipe Rec3, final Recipe Rec4, final boolean[] bool1, final boolean[] bool2, final boolean[] bool3, final boolean[] bool4) {

        final JFrame fr2 = new JFrame();
        fr2.setLayout(new BorderLayout());
        JPanel mainPanel = new JPanel(new GridLayout(4, 2));
        JScrollPane mainScroll = new JScrollPane(mainPanel);
        JPanel bot = new JPanel(new GridLayout(1, 2));
        fr2.add(mainScroll, BorderLayout.CENTER);
        fr2.add(bot, BorderLayout.SOUTH);
        fr2.setResizable(false);
        fr2.setSize(735, 600);
        fr2.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        Dimension dim = Toolkit.getDefaultToolkit().getScreenSize();
        fr2.setLocation(dim.width / 2 - fr2.getSize().width / 2, dim.height / 2 - fr2.getSize().height / 2);
        
        JButton butForNewIng = new JButton("New Ingredients");
        JButton btStPage = new JButton("Home Page");
        bot.add(btStPage);
        bot.add(butForNewIng);
        
        fr2.setVisible(true);

        JLabel Re1 = new JLabel("Recipe 1");
        JLabel Re2 = new JLabel("Recipe 2");
        JLabel Re3 = new JLabel("Recipe 3");
        JLabel Re4 = new JLabel("Recipe 4");
        Re1.setHorizontalAlignment(JLabel.CENTER);
        Re2.setHorizontalAlignment(JLabel.CENTER);
        Re3.setHorizontalAlignment(JLabel.CENTER);
        Re4.setHorizontalAlignment(JLabel.CENTER);
        
        
        
        
        
        
        
        
        
        
        

        JPanel paRec1 = new JPanel(new BorderLayout());
        

        JPanel paIng = new JPanel(new GridLayout(8, 1));
        JScrollPane sc = new JScrollPane(paIng);
        sc.setPreferredSize(new Dimension(50, 50));
        paRec1.add(Re1, BorderLayout.NORTH);
        paRec1.add(sc, BorderLayout.CENTER);
        
       
        

        final Color lightGreen = new Color(196, 237, 182);

        /*  (prosoxi .. ta checkbox einai energopoihmena omos efoson
            den xrisimopoioute ta afino enabled gia to visual ... 
            gia na min epitrepete na alaxoun prepei na ginoun setEditable(False); ola*/
        for (int i = 1; i <= 8; i++) {
            JCheckBox cb = new JCheckBox(Rec1.ingredients[i]);
            cb.setIcon(new ImageIcon("images/cb.png"));

            if (bool1[i] == true) {
                r1 = r1 + 1;

                cb.setBackground(lightGreen);
                cb.setSelected(true);

            } else {
                cb.setEnabled(false);
            }

            paIng.add(cb);
        }

        JPanel paRec2 = new JPanel(new BorderLayout());
        JPanel paIng2 = new JPanel(new GridLayout(8, 1));
        JScrollPane sc2 = new JScrollPane(paIng2);
        sc2.setPreferredSize(new Dimension(50, 50));
        paRec2.setVisible(true);
        
        paRec2.add(Re2, BorderLayout.NORTH);
        paRec2.add(sc2, BorderLayout.CENTER);
        for (int i = 1; i <= 8; i++) {

            JCheckBox cb = new JCheckBox(Rec2.ingredients[i]);
            cb.setIcon(new ImageIcon("images/cb.png"));
            if (bool2[i] == true) {
                r2 = r2 + 1;
                cb.setBackground(lightGreen);
                cb.setSelected(true);
            } else {
                cb.setEnabled(false);
            }

            paIng2.add(cb);

        }

        JPanel paRec3 = new JPanel(new BorderLayout());
        JPanel paIng3 = new JPanel(new GridLayout(11, 1));
        JScrollPane sc3 = new JScrollPane(paIng3);
        sc3.setPreferredSize(new Dimension(50, 50));
        paRec3.setVisible(true);
        
        paRec3.add(Re3, BorderLayout.NORTH);
        paRec3.add(sc3, BorderLayout.CENTER);
        for (int i = 1; i <= 11; i++) {
            JCheckBox cb = new JCheckBox(Rec3.ingredients[i]);
            cb.setIcon(new ImageIcon("images/cb.png"));
            if (bool3[i] == true) {
                r3 = r3 + 1;

                cb.setBackground(lightGreen);

                cb.setSelected(true);
            } else {
                cb.setEnabled(false);
            }

            paIng3.add(cb);

        }

        JPanel paRec4 = new JPanel(new BorderLayout());
        JPanel paIng4 = new JPanel(new GridLayout(7, 1));
        JScrollPane sc4 = new JScrollPane(paIng4);
        sc4.setPreferredSize(new Dimension(50, 50));
        paRec4.setVisible(true);
        
        paRec4.add(Re4, BorderLayout.NORTH);
        paRec4.add(sc4, BorderLayout.CENTER);
        for (int i = 1; i <= 7; i++) {
            JCheckBox cb = new JCheckBox(Rec4.ingredients[i]);
            cb.setIcon(new ImageIcon("images/cb.png"));
            if (bool4[i] == true) {

                r4 = r4 + 1;
                cb.setBackground(lightGreen);
                cb.setSelected(true);
            } else {
                cb.setEnabled(false);
            }

            paIng4.add(cb);

        }
        
        DefaultPieDataset dataset = new DefaultPieDataset();
        dataset.setValue("Ingredients you don't have : "+(8-r1), 8-r1);
        dataset.setValue("Ingredients you have : "+r1, r1);
        
        
        JFreeChart chart1 = ChartFactory.createPieChart("Recipe 1", dataset, false, false, false);
        ChartPanel p = new ChartPanel(chart1);
        
        DefaultPieDataset dataset2 = new DefaultPieDataset();
        dataset2.setValue("Ingredients you don't have : "+(8-r2), 8-r2);
        dataset2.setValue("Ingredients you have : "+r2, r2);
        JFreeChart chart2 = ChartFactory.createPieChart("Recipe 2", dataset2, false, false, false);
        ChartPanel p2 = new ChartPanel(chart2);
        
        DefaultPieDataset dataset3 = new DefaultPieDataset();
        dataset3.setValue("Ingredients you don't have : "+(11-r3), 11-r3);
        dataset3.setValue("Ingredients you have : "+r3, r3);
        JFreeChart chart3 = ChartFactory.createPieChart("Recipe 3", dataset3, false, false, false);
        ChartPanel p3 = new ChartPanel(chart3);
        
        DefaultPieDataset dataset4 = new DefaultPieDataset();
        dataset4.setValue("Ingredients you don't have : "+(7-r4), 7-r4);
        dataset4.setValue("Ingredients you have : "+r4, r4);
        JFreeChart chart4 = ChartFactory.createPieChart("Recipe 4", dataset4, false, false, false);
        ChartPanel p4 = new ChartPanel(chart4);
        
        mainPanel.setPreferredSize(new Dimension(700, 900));
        mainPanel.add(paRec1);
        mainPanel.add(p);
        mainPanel.add(paRec2);
        mainPanel.add(p2);
        mainPanel.add(paRec3);
        mainPanel.add(p3);
        mainPanel.add(paRec4);
        mainPanel.add(p4);
        

        String s1 = "";
        String s2 = "";
        String s3 = "";
        String s4 = "";

        if (r1 == 8) {
            s1 = " Recipe 1 ";
        }

        if (r2 == 8) {
            s2 = " Recipe 2 ";
        }

        if (r3 == 11) {
            s3 = " Recipe 3 ";
        }

        if (r4 == 7) {
            s4 = " Recipe 4. ";
        }

        if (r1 < 8 && r2 < 8 && r3 < 11 && r4 < 7) {
            JOptionPane.showMessageDialog(null, "You cannot create any recipes with your current ingredients");
        } else {
            JOptionPane.showMessageDialog(null, "The recipes you can create with your ingredients are : " + s1 + s2 + s3 + s4);
        }

        

        butForNewIng.addActionListener(new java.awt.event.ActionListener() {
            @Override
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                IngredientsGUI gui = new IngredientsGUI(Rec1, Rec2, Rec3, Rec4);
                fr2.dispose();
            }
        });

        btStPage.addActionListener(new java.awt.event.ActionListener() {
            @Override
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                final Recipe Rec1 = new Recipe();
                final Recipe Rec2 = new Recipe();
                final Recipe Rec3 = new Recipe();
                final Recipe Rec4 = new Recipe();
                new BestChoice(Rec1, Rec2, Rec3, Rec4);
                new FirstPanel(Rec1, Rec2, Rec3, Rec4);
                fr2.dispose();

            }
        });

        

    }
}
