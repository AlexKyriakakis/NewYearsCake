
package newYearCake;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Toolkit;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingConstants;

public class FirstPanel {

    FirstPanel(final Recipe Rec1, final Recipe Rec2, final Recipe Rec3, final Recipe Rec4){
        final JFrame myJf = new JFrame();
        myJf.setSize(900, 360);
        myJf.setResizable(false);
        myJf.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        Dimension dim = Toolkit.getDefaultToolkit().getScreenSize();
        myJf.setLocation(dim.width / 2 - myJf.getSize().width / 2, dim.height / 2 - myJf.getSize().height / 2);

        JPanel topPanel = new JPanel(new BorderLayout());
        
        JLabel Epikefalida = new JLabel(new ImageIcon("images/tree.gif"));
        JLabel Epikefalida2 = new JLabel(new ImageIcon("images/f2.gif"));

        JLabel Epikefalida3 = new JLabel("Optimal New Year Cake Choice Program");
        Epikefalida3.setFont(new Font("Serif", Font.PLAIN, 30));
        Epikefalida3.setBackground(Color.WHITE);
        Epikefalida3.setHorizontalAlignment(JLabel.CENTER);
        
        JLabel Epikefalida4 = new JLabel(new ImageIcon("images/f4.gif"), SwingConstants.CENTER);
        Epikefalida4.setFont(new Font("Serif", Font.PLAIN, 30));
        Epikefalida3.setForeground(Color.red);
        JPanel top = new JPanel();
        top.setBackground(Color.white);
        top.add(Epikefalida);
        top.add(Epikefalida4);
        top.add(Epikefalida2);
        
        topPanel.add(top,BorderLayout.CENTER);
        topPanel.add(Epikefalida3,BorderLayout.NORTH);
        topPanel.setBackground(Color.WHITE);
        top.setBackground(Color.WHITE);
       

        JButton but1 = new JButton("Calorie-based choice");
        JButton but2 = new JButton("Ingredient-based choice");

        JPanel bot = new JPanel();
        bot.add(but1);
        bot.add(but2);
        bot.setBackground(Color.white);

        myJf.add(topPanel, BorderLayout.NORTH);
        myJf.add(bot, BorderLayout.CENTER);
        myJf.setVisible(true);

        but1.addActionListener(new java.awt.event.ActionListener() {
            @Override
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                try {
                    CakeCaloriesGUI pap2 = new CakeCaloriesGUI(Rec1, Rec2, Rec3, Rec4);
                } catch (IOException ex) {
                    Logger.getLogger(NewYearCake.class.getName()).log(Level.SEVERE, null, ex);
                }
                myJf.dispose();

            }
        });

        but2.addActionListener(new java.awt.event.ActionListener() {
            @Override
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                myJf.dispose();
                new IngredientsGUI(Rec1, Rec2, Rec3, Rec4);

            }
        });

    }
}
