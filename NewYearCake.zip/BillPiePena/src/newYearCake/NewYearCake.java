
package newYearCake;

import java.io.IOException;


public class NewYearCake {


    public static void main(String[] args) throws IOException {

        
        final Recipe Rec1 = new Recipe();
        final Recipe Rec2 = new Recipe();
        final Recipe Rec3 = new Recipe();
        final Recipe Rec4 = new Recipe();
        new BestChoice(Rec1, Rec2, Rec3, Rec4);
        new FirstPanel(Rec1,Rec2,Rec3,Rec4);

    }
}
