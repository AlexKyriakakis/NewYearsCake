
package newYearCake;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;

public class IngredientsGUI {

    int i;

    public IngredientsGUI(final Recipe Rec1, final Recipe Rec2, final Recipe Rec3, final Recipe Rec4) {

        final JFrame mainFrame = new JFrame();
        mainFrame.setLayout(new BorderLayout());
        mainFrame.setSize(600, 500);
        JPanel mainPanel = new JPanel(new GridLayout(4, 4, 3, 3));
        mainFrame.setBackground(Color.WHITE);
        mainPanel.setBackground(Color.WHITE);
        JScrollPane scroll = new JScrollPane(mainPanel);
        JLabel northLabel = new JLabel("Choose The ingredients you possess");
        northLabel.setBackground(Color.WHITE);
        northLabel.setOpaque(true);
        northLabel.setFont(new Font("Serif", Font.PLAIN, 25));
        northLabel.setHorizontalAlignment(JLabel.CENTER);
        JButton done = new JButton("DONE");
        
        mainFrame.add(northLabel, BorderLayout.NORTH);
        mainFrame.add(done, BorderLayout.SOUTH);
        mainFrame.add(scroll, BorderLayout.CENTER);
        mainFrame.setResizable(false);
        mainFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        Dimension dim = Toolkit.getDefaultToolkit().getScreenSize();
        mainFrame.setLocation(dim.width/2-mainFrame.getSize().width/2, dim.height/2-mainFrame.getSize().height/2);

        final boolean[] bool1 = new boolean[20];
        final boolean[] bool2 = new boolean[20];
        final boolean[] bool3 = new boolean[20];
        final boolean[] bool4 = new boolean[20];

        JPanel ingrPanel0 = new JPanel();
        final JCheckBox ingrCB0 = new JCheckBox("Butter");
        JLabel iconLabel0 = new JLabel(new ImageIcon("images/ingr0.jpg"));
        ingrCB0.setBackground(Color.WHITE);
        ingrPanel0.setBackground(Color.WHITE);
        ingrPanel0.setLayout(new BorderLayout());
        ingrPanel0.add(iconLabel0, BorderLayout.CENTER);
        ingrPanel0.add(ingrCB0, BorderLayout.SOUTH);
        mainPanel.add(ingrPanel0);
        
        JPanel ingrPanel1 = new JPanel();
        final JCheckBox ingrCB1 = new JCheckBox("Eggs");
        JLabel iconLabel1 = new JLabel(new ImageIcon("images/ingr1.jpg"));
        ingrCB1.setBackground(Color.WHITE);
        ingrPanel1.setBackground(Color.WHITE);
        ingrPanel1.setLayout(new BorderLayout());
        ingrPanel1.add(iconLabel1, BorderLayout.CENTER);
        ingrPanel1.add(ingrCB1, BorderLayout.SOUTH);
        mainPanel.add(ingrPanel1);
        
        JPanel ingrPanel2 = new JPanel();
        final JCheckBox ingrCB2 = new JCheckBox("Flour");
        JLabel iconLabel2 = new JLabel(new ImageIcon("images/ingr2.jpg"));
        ingrCB2.setBackground(Color.WHITE);
        ingrPanel2.setBackground(Color.WHITE);
        ingrPanel2.setLayout(new BorderLayout());
        ingrPanel2.add(iconLabel2, BorderLayout.CENTER);
        ingrPanel2.add(ingrCB2, BorderLayout.SOUTH);
        mainPanel.add(ingrPanel2);
        
        JPanel ingrPanel3 = new JPanel();
        final JCheckBox ingrCB3 = new JCheckBox("Cognac");
        JLabel iconLabel3 = new JLabel(new ImageIcon("images/ingr3.jpg"));
        ingrCB3.setBackground(Color.WHITE);
        ingrPanel3.setBackground(Color.WHITE);
        ingrPanel3.setLayout(new BorderLayout());
        ingrPanel3.add(iconLabel3, BorderLayout.CENTER);
        ingrPanel3.add(ingrCB3, BorderLayout.SOUTH);
        mainPanel.add(ingrPanel3);
        
        JPanel ingrPanel4 = new JPanel();
        final JCheckBox ingrCB4 = new JCheckBox("Sugar");
        JLabel iconLabel4 = new JLabel(new ImageIcon("images/ingr4.jpg"));
        ingrCB4.setBackground(Color.WHITE);
        ingrPanel4.setBackground(Color.WHITE);
        ingrPanel4.setLayout(new BorderLayout());
        ingrPanel4.add(iconLabel4, BorderLayout.CENTER);
        ingrPanel4.add(ingrCB4, BorderLayout.SOUTH);
        mainPanel.add(ingrPanel4);
        
        JPanel ingrPanel5 = new JPanel();
        final JCheckBox ingrCB5 = new JCheckBox("Orage Juice");
        JLabel iconLabel5 = new JLabel(new ImageIcon("images/ingr5.jpg"));
        ingrCB5.setBackground(Color.WHITE);
        ingrPanel5.setBackground(Color.WHITE);
        ingrPanel5.setLayout(new BorderLayout());
        ingrPanel5.add(iconLabel5, BorderLayout.CENTER);
        ingrPanel5.add(ingrCB5, BorderLayout.SOUTH);
        mainPanel.add(ingrPanel5);
        
        JPanel ingrPanel6 = new JPanel();
        final JCheckBox ingrCB6 = new JCheckBox("Baking Soda");
        JLabel iconLabel6 = new JLabel(new ImageIcon("images/ingr6.jpg"));
        ingrCB6.setBackground(Color.WHITE);
        ingrPanel6.setBackground(Color.WHITE);
        ingrPanel6.setLayout(new BorderLayout());
        ingrPanel6.add(iconLabel6, BorderLayout.CENTER);
        ingrPanel6.add(ingrCB6, BorderLayout.SOUTH);
        mainPanel.add(ingrPanel6);
        
        JPanel ingrPanel7 = new JPanel();
        final JCheckBox ingrCB7 = new JCheckBox("Powdered Sugar");
        JLabel iconLabel7 = new JLabel(new ImageIcon("images/ingr7.jpg"));
        ingrCB7.setBackground(Color.WHITE);
        ingrPanel7.setBackground(Color.WHITE);
        ingrPanel7.setLayout(new BorderLayout());
        ingrPanel7.add(iconLabel7, BorderLayout.CENTER);
        ingrPanel7.add(ingrCB7, BorderLayout.SOUTH);
        mainPanel.add(ingrPanel7);
        
        JPanel ingrPanel8 = new JPanel();
        final JCheckBox ingrCB8 = new JCheckBox("Milk");
        JLabel iconLabel8 = new JLabel(new ImageIcon("images/ingr8.jpg"));
        ingrCB8.setBackground(Color.WHITE);
        ingrPanel8.setBackground(Color.WHITE);
        ingrPanel8.setLayout(new BorderLayout());
        ingrPanel8.add(iconLabel8, BorderLayout.CENTER);
        ingrPanel8.add(ingrCB8, BorderLayout.SOUTH);
        mainPanel.add(ingrPanel8);
        
        JPanel ingrPanel9 = new JPanel();
        final JCheckBox ingrCB9 = new JCheckBox("Orange Zest");
        JLabel iconLabel9 = new JLabel(new ImageIcon("images/ingr9.jpg"));
        ingrCB9.setBackground(Color.WHITE);
        ingrPanel9.setBackground(Color.WHITE);
        ingrPanel9.setLayout(new BorderLayout());
        ingrPanel9.add(iconLabel9, BorderLayout.CENTER);
        ingrPanel9.add(ingrCB9, BorderLayout.SOUTH);
        mainPanel.add(ingrPanel9);
        
        JPanel ingrPanel10 = new JPanel();
        final JCheckBox ingrCB10 = new JCheckBox("Margarine");
        JLabel iconLabel10 = new JLabel(new ImageIcon("images/ingr10.jpg"));
        ingrCB10.setBackground(Color.WHITE);
        ingrPanel10.setBackground(Color.WHITE);
        ingrPanel10.setLayout(new BorderLayout());
        ingrPanel10.add(iconLabel10, BorderLayout.CENTER);
        ingrPanel10.add(ingrCB10, BorderLayout.SOUTH);
        mainPanel.add(ingrPanel10);
        
        JPanel ingrPanel11 = new JPanel();
        final JCheckBox ingrCB11 = new JCheckBox("'GIOTIS' Flour");
        JLabel iconLabel11 = new JLabel(new ImageIcon("images/ingr11.jpg"));
        ingrCB11.setBackground(Color.WHITE);
        ingrPanel11.setBackground(Color.WHITE);
        ingrPanel11.setLayout(new BorderLayout());
        ingrPanel11.add(iconLabel11, BorderLayout.CENTER);
        ingrPanel11.add(ingrCB11, BorderLayout.SOUTH);
        mainPanel.add(ingrPanel11);
        
        JPanel ingrPanel12 = new JPanel();
        final JCheckBox ingrCB12 = new JCheckBox("Baking Powder");
        JLabel iconLabel12 = new JLabel(new ImageIcon("images/ingr12.jpg"));
        ingrCB12.setBackground(Color.WHITE);
        ingrPanel12.setBackground(Color.WHITE);
        ingrPanel12.setLayout(new BorderLayout());
        ingrPanel12.add(iconLabel12, BorderLayout.CENTER);
        ingrPanel12.add(ingrCB12, BorderLayout.SOUTH);
        mainPanel.add(ingrPanel12);
        
        JPanel ingrPanel13 = new JPanel();
        final JCheckBox ingrCB13 = new JCheckBox("Salt");
        JLabel iconLabel13 = new JLabel(new ImageIcon("images/ingr13.jpg"));
        ingrCB13.setBackground(Color.WHITE);
        ingrPanel13.setBackground(Color.WHITE);
        ingrPanel13.setLayout(new BorderLayout());
        ingrPanel13.add(iconLabel13, BorderLayout.CENTER);
        ingrPanel13.add(ingrCB13, BorderLayout.SOUTH);
        mainPanel.add(ingrPanel13);
        
        JPanel ingrPanel14 = new JPanel();
        final JCheckBox ingrCB14 = new JCheckBox("Hazelnuts");
        JLabel iconLabel14 = new JLabel(new ImageIcon("images/ingr14.jpg"));
        ingrCB14.setBackground(Color.WHITE);
        ingrPanel14.setBackground(Color.WHITE);
        ingrPanel14.setLayout(new BorderLayout());
        ingrPanel14.add(iconLabel14, BorderLayout.CENTER);
        ingrPanel14.add(ingrCB14, BorderLayout.SOUTH);
        mainPanel.add(ingrPanel14);
        
        JPanel ingrPanel15 = new JPanel();
        final JCheckBox ingrCB15 = new JCheckBox("Couverture");
        JLabel iconLabel15 = new JLabel(new ImageIcon("images/ingr15.jpg"));
        ingrCB15.setBackground(Color.WHITE);
        ingrPanel15.setBackground(Color.WHITE);
        ingrPanel15.setLayout(new BorderLayout());
        ingrPanel15.add(iconLabel15, BorderLayout.CENTER);
        ingrPanel15.add(ingrCB15, BorderLayout.SOUTH);
        mainPanel.add(ingrPanel15);
        
        
        

        
        
        for (i = 1; i <= 16; i++) {
            bool1[i] = false;
            bool2[i] = false;
            bool3[i] = false;
            bool4[i] = false;   
        }
        
       
        
        
      

        ingrCB0.addItemListener(new ItemListener() {//voutiro

            @Override
            public void itemStateChanged(ItemEvent e) {

                if (e.getStateChange() == ItemEvent.SELECTED) {
                    bool1[1] = true;
                    bool2[1] = true;
                    bool4[1] = true;
                } else {
                    bool1[1] = false;
                    bool2[1] = false;
                    bool4[1] = false;
                }

            }
        });

        ingrCB1.addItemListener(new ItemListener() {//avga

            @Override
            public void itemStateChanged(ItemEvent e) {

                if (e.getStateChange() == ItemEvent.SELECTED) {
                    bool1[2] = true;
                    bool2[2] = true;
                    bool3[3] = true;
                    bool4[3] = true;
                } else {
                    bool1[2] = false;
                    bool2[2] = false;
                    bool3[3] = false;
                    bool4[3] = false;
                }

            }
        });

        ingrCB2.addItemListener(new ItemListener() {//alevri

            @Override
            public void itemStateChanged(ItemEvent e) {

                if (e.getStateChange() == ItemEvent.SELECTED) {
                    bool1[3] = true;
                    bool2[3] = true;

                } else {
                    bool1[3] = false;
                    bool2[3] = false;

                }

            }
        });

        ingrCB3.addItemListener(new ItemListener() {//koniak

            @Override
            public void itemStateChanged(ItemEvent e) {

                if (e.getStateChange() == ItemEvent.SELECTED) {
                    bool1[4] = true;
                    bool2[5] = true;
                    bool4[4] = true;
                } else {
                    bool1[4] = false;
                    bool2[5] = false;
                    bool4[4] = false;
                }

            }
        });

        ingrCB4.addItemListener(new ItemListener() {//zaxari

            @Override
            public void itemStateChanged(ItemEvent e) {

                if (e.getStateChange() == ItemEvent.SELECTED) {
                    bool1[5] = true;
                    bool2[6] = true;
                    bool3[2] = true;
                    bool4[2] = true;
                } else {
                    bool1[5] = false;
                    bool2[6] = false;
                    bool3[2] = false;
                    bool4[2] = false;
                }

            }
        });

        ingrCB5.addItemListener(new ItemListener() {//ximos portokaliou

            @Override
            public void itemStateChanged(ItemEvent e) {

                if (e.getStateChange() == ItemEvent.SELECTED) {
                    bool1[6] = true;
                    bool3[8] = true;
                    bool4[6] = true;
                } else {
                    bool1[6] = false;
                    bool3[8] = false;
                    bool4[6] = false;
                }

            }
        });

        ingrCB6.addItemListener(new ItemListener() {//mageiriki soda

            @Override
            public void itemStateChanged(ItemEvent e) {

                if (e.getStateChange() == ItemEvent.SELECTED) {
                    bool1[7] = true;
                    bool2[7] = true;
                } else {
                    bool1[7] = false;
                    bool2[7] = false;
                }

            }
        });

        ingrCB7.addItemListener(new ItemListener() {//zaxari axni

            @Override
            public void itemStateChanged(ItemEvent e) {

                if (e.getStateChange() == ItemEvent.SELECTED) {
                    bool1[8] = true;
                    bool3[11] = true;
                } else {
                    bool1[8] = false;
                    bool3[11] = false;
                }

            }
        });

        ingrCB8.addItemListener(new ItemListener() {//gala

            @Override
            public void itemStateChanged(ItemEvent e) {

                if (e.getStateChange() == ItemEvent.SELECTED) {
                    bool2[4] = true;
                } else {
                    bool2[4] = false;
                }

            }
        });

        ingrCB9.addItemListener(new ItemListener() {//Ksisma portokaliou

            @Override
            public void itemStateChanged(ItemEvent e) {

                if (e.getStateChange() == ItemEvent.SELECTED) {
                    bool2[8] = true;
                    bool3[7] = true;
                    bool4[7] = true;
                } else {
                    bool2[8] = false;
                    bool3[7] = false;
                    bool4[7] = false;
                }

            }
        });

        ingrCB10.addItemListener(new ItemListener() {//margarini

            @Override
            public void itemStateChanged(ItemEvent e) {

                if (e.getStateChange() == ItemEvent.SELECTED) {
                    bool3[1] = true;
                } else {
                    bool3[1] = false;
                }

            }
        });

        ingrCB11.addItemListener(new ItemListener() {//farina giotis

            @Override
            public void itemStateChanged(ItemEvent e) {

                if (e.getStateChange() == ItemEvent.SELECTED) {
                    bool3[4] = true;
                    bool4[5] = true;
                } else {
                    bool3[4] = false;
                    bool4[5] = false;
                }

            }
        });

        ingrCB12.addItemListener(new ItemListener() {//baking powder

            @Override
            public void itemStateChanged(ItemEvent e) {

                if (e.getStateChange() == ItemEvent.SELECTED) {
                    bool3[5] = true;
                } else {
                    bool3[5] = false;
                }

            }
        });

        ingrCB13.addItemListener(new ItemListener() {//alati

            @Override
            public void itemStateChanged(ItemEvent e) {

                if (e.getStateChange() == ItemEvent.SELECTED) {
                    bool3[6] = true;
                } else {
                    bool3[6] = false;
                }

            }
        });

        ingrCB14.addItemListener(new ItemListener() {//Fountoukia

            @Override
            public void itemStateChanged(ItemEvent e) {

                if (e.getStateChange() == ItemEvent.SELECTED) {
                    bool3[9] = true;
                } else {
                    bool3[9] = false;
                }

            }
        });

        ingrCB15.addItemListener(new ItemListener() {//kouvertoura

            @Override
            public void itemStateChanged(ItemEvent e) {

                if (e.getStateChange() == ItemEvent.SELECTED) {
                    bool3[10] = true;
                } else {
                    bool3[10] = false;
                }

            }
        });


        
        
        
        
        ingrPanel0.addMouseListener(new MouseAdapter() { 
          @Override
          public void mousePressed(MouseEvent me) { 
            
              ingrCB0.doClick();
              
          } 
        }); 
        
        ingrPanel1.addMouseListener(new MouseAdapter() { 
          @Override
          public void mousePressed(MouseEvent me) { 
            
              ingrCB1.doClick();
              
          } 
        }); 
        
        ingrPanel2.addMouseListener(new MouseAdapter() { 
          @Override
          public void mousePressed(MouseEvent me) { 
            
              ingrCB2.doClick();
              
          } 
        }); 
        
        ingrPanel3.addMouseListener(new MouseAdapter() { 
          @Override
          public void mousePressed(MouseEvent me) { 
            
              ingrCB3.doClick();
              
          } 
        }); 
        
        ingrPanel4.addMouseListener(new MouseAdapter() { 
          @Override
          public void mousePressed(MouseEvent me) { 
            
              ingrCB4.doClick();
              
          } 
        }); 
        
        ingrPanel5.addMouseListener(new MouseAdapter() { 
          @Override
          public void mousePressed(MouseEvent me) { 
            
              ingrCB5.doClick();
              
          } 
        }); 
        
        ingrPanel6.addMouseListener(new MouseAdapter() { 
          @Override
          public void mousePressed(MouseEvent me) { 
            
              ingrCB6.doClick();
              
          } 
        }); 
        
        ingrPanel7.addMouseListener(new MouseAdapter() { 
          @Override
          public void mousePressed(MouseEvent me) { 
            
              ingrCB7.doClick();
              
          } 
        }); 
        
        ingrPanel8.addMouseListener(new MouseAdapter() { 
          @Override
          public void mousePressed(MouseEvent me) { 
            
              ingrCB8.doClick();
              
          } 
        }); 
        
        ingrPanel9.addMouseListener(new MouseAdapter() { 
          @Override
          public void mousePressed(MouseEvent me) { 
            
              ingrCB9.doClick();
              
          } 
        }); 
        
        ingrPanel10.addMouseListener(new MouseAdapter() { 
          @Override
          public void mousePressed(MouseEvent me) { 
            
              ingrCB10.doClick();
              
          } 
        }); 
        
        ingrPanel11.addMouseListener(new MouseAdapter() { 
          @Override
          public void mousePressed(MouseEvent me) { 
            
              ingrCB11.doClick();
              
          } 
        }); 
        
        ingrPanel12.addMouseListener(new MouseAdapter() { 
          @Override
          public void mousePressed(MouseEvent me) { 
            
              ingrCB12.doClick();
              
          } 
        }); 
        
        ingrPanel13.addMouseListener(new MouseAdapter() { 
          @Override
          public void mousePressed(MouseEvent me) { 
            
              ingrCB13.doClick();
              
          } 
        }); 
        
        ingrPanel14.addMouseListener(new MouseAdapter() { 
          @Override
          public void mousePressed(MouseEvent me) { 
            
              ingrCB14.doClick();
              
          } 
        }); 
        
        ingrPanel15.addMouseListener(new MouseAdapter() { 
          @Override
          public void mousePressed(MouseEvent me) { 
            
              ingrCB15.doClick();
              
          } 
        }); 
        
        
        done.addActionListener(new ActionListener() {     
            @Override
            public void actionPerformed(ActionEvent e) {
                mainFrame.dispose();
                CakeIngredientsGUI gui2 = new CakeIngredientsGUI(Rec1,Rec2,Rec3,Rec4,bool1,bool2,bool3,bool4);
            }
        });
            
            
            
      


        mainFrame.setVisible(true);
    }

}
