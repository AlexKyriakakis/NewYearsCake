package newYearCake;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.Toolkit;
import java.io.IOException;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSlider;
import javax.swing.JTextArea;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.data.category.DefaultCategoryDataset;

public class CakeCaloriesGUI {

    int rec1Guard = 0;
    int rec2Guard = 0;
    int rec3Guard = 0;
    int rec4Guard = 0;

    public CakeCaloriesGUI(final Recipe Rec1, final Recipe Rec2, final Recipe Rec3, final Recipe Rec4) throws IOException {

        final JFrame mainFrame = new JFrame();
        mainFrame.setTitle("New Year Cake Recipes");
        mainFrame.setResizable(false);
        final JPanel jPanel1 = new JPanel();
        JLabel jLabel2 = new JLabel();
        final JSlider jSlider2 = new JSlider();
        JLabel jLabel1 = new JLabel();
        JLabel jLabel3 = new JLabel();
        final JLabel SliderValue = new JLabel();
        final JButton jButton1 = new JButton();
        final JButton jButton2 = new JButton();
        final JButton jButton3 = new JButton();
        final JButton jButton4 = new JButton();
        final JButton jButton5 = new JButton();
        final JTextArea rec1Text = new JTextArea("\n                    NewYearCake 1\n\n");
        final JTextArea rec2Text = new JTextArea("\n                    NewYearCake 2\n\n");
        final JTextArea rec3Text = new JTextArea("\n                    NewYearCake 3\n\n");
        final JTextArea rec4Text = new JTextArea("\n                    NewYearCake 4\n\n");

        rec1Text.setEditable(false);
        rec2Text.setEditable(false);
        rec3Text.setEditable(false);
        rec4Text.setEditable(false);

        JScrollPane rec1Scroll = new JScrollPane(rec1Text);
        JScrollPane rec2Scroll = new JScrollPane(rec2Text);
        JScrollPane rec3Scroll = new JScrollPane(rec3Text);
        JScrollPane rec4Scroll = new JScrollPane(rec4Text);

        final JFrame rec1Frame = new JFrame();
        final JFrame rec2Frame = new JFrame();
        final JFrame rec3Frame = new JFrame();
        final JFrame rec4Frame = new JFrame();

        JDialog.setDefaultLookAndFeelDecorated(true);
        final JDialog rec1Dialog = new JDialog(rec1Frame, "Recipe 1", true);
        final JDialog rec2Dialog = new JDialog(rec2Frame, "Recipe 2", true);
        final JDialog rec3Dialog = new JDialog(rec3Frame, "Recipe 3", true);
        final JDialog rec4Dialog = new JDialog(rec4Frame, "Recipe 4", true);

        rec1Dialog.setSize(280, 370);
        rec2Dialog.setSize(280, 370);
        rec3Dialog.setSize(280, 370);
        rec4Dialog.setSize(280, 370);
        rec1Dialog.setResizable(false);
        rec2Dialog.setResizable(false);
        rec3Dialog.setResizable(false);
        rec4Dialog.setResizable(false);

        rec1Dialog.add(rec1Scroll);
        rec2Dialog.add(rec2Scroll);
        rec3Dialog.add(rec3Scroll);
        rec4Dialog.add(rec4Scroll);

        final JFrame fFrame = new JFrame();
        fFrame.setResizable(false);
        final JSlider slide = new JSlider();
        slide.setBackground(Color.WHITE);
        JLabel calLabel = new JLabel("           Desirable cake calories.");

        calLabel.setFont(new Font("Serif", Font.PLAIN, 25));
        JButton go = new JButton("SELECT");
        JLabel min = new JLabel("                                            500");
        JLabel max = new JLabel("3000");
        final JLabel slideValue = new JLabel();
        JLabel center = new JLabel(new ImageIcon("images/backgr.jpg"));
        center.setLayout(new GridLayout(2, 1));
        JPanel centerBot = new JPanel(new GridLayout(1, 3, 4, 4));
        centerBot.setBackground(Color.WHITE);
        centerBot.add(min);
        centerBot.add(slide);
        centerBot.add(max);
        center.add(slideValue);
        center.add(centerBot);

        JLabel startLabel = new JLabel(new ImageIcon("images/white.jpg"));
        startLabel.setLayout(new BorderLayout());
        startLabel.setSize(500, 300);

        startLabel.add(calLabel, BorderLayout.NORTH);
        startLabel.add(go, BorderLayout.SOUTH);
        startLabel.add(center, BorderLayout.CENTER);

        fFrame.add(startLabel);
        fFrame.setSize(500, 300);
        Dimension dim = Toolkit.getDefaultToolkit().getScreenSize();
        fFrame.setLocation(dim.width / 2 - fFrame.getSize().width / 2, dim.height / 2 - fFrame.getSize().height / 2);
        fFrame.setVisible(true);

        final Color lightGreen = new Color(196, 237, 182);

        slide.setMaximum(3000);
        slide.setMinimum(500);
        slide.addChangeListener(new ChangeListener() {
            @Override
            public void stateChanged(ChangeEvent ce) {

                slideValue.setText("Selected Calories : " + String.valueOf(slide.getValue()));
                slideValue.setHorizontalAlignment(JLabel.CENTER);
            }
        });

        mainFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        fFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        jPanel1.setLayout(new BorderLayout());

        jLabel2.setText("3000");

        jSlider2.setMaximum(3000);
        jSlider2.setMinimum(500);
        jSlider2.addChangeListener(new ChangeListener() {
            @Override
            public void stateChanged(ChangeEvent ce) {
                SliderValue.setText(String.valueOf(jSlider2.getValue()));
                int playerchoice = jSlider2.getValue();

                int calDiff1 = Math.abs(jSlider2.getValue() - Rec1.calories);
                int calDiff2 = Math.abs(jSlider2.getValue() - Rec2.calories);
                int calDiff3 = Math.abs(jSlider2.getValue() - Rec3.calories);
                int calDiff4 = Math.abs(jSlider2.getValue() - Rec4.calories);

                DefaultCategoryDataset barchartData = new DefaultCategoryDataset();

                if (calDiff1 <= calDiff2 && calDiff1 <= calDiff3 && calDiff1 <= calDiff4) {
                    barchartData.setValue(Rec2.calories, "Recipes", "Recipe 2");
                    barchartData.setValue(Rec3.calories, "Recipes", "Recipe 3");
                    barchartData.setValue(Rec4.calories, "Recipes", "Recipe 4");
                    barchartData.setValue(Rec1.calories, "Suggested Recipe", "Recipe 1");
                    jButton2.setBackground(lightGreen);
                    jButton3.setBackground(null);
                    jButton4.setBackground(null);
                    jButton5.setBackground(null);

                } else if (calDiff2 <= calDiff1 && calDiff2 <= calDiff3 && calDiff2 <= calDiff4) {
                    barchartData.setValue(Rec1.calories, "Recipes", "Recipe 1");
                    barchartData.setValue(Rec3.calories, "Recipes", "Recipe 3");
                    barchartData.setValue(Rec4.calories, "Recipes", "Recipe 4");
                    barchartData.setValue(Rec2.calories, "Suggested Recipe", "Recipe 2");
                    jButton2.setBackground(null);
                    jButton3.setBackground(lightGreen);
                    jButton4.setBackground(null);
                    jButton5.setBackground(null);
                } else if (calDiff3 <= calDiff2 && calDiff3 <= calDiff1 && calDiff3 <= calDiff4) {
                    barchartData.setValue(Rec1.calories, "Recipes", "Recipe 1");
                    barchartData.setValue(Rec2.calories, "Recipes", "Recipe 2");
                    barchartData.setValue(Rec4.calories, "Recipes", "Recipe 4");
                    barchartData.setValue(Rec3.calories, "Suggested Recipe", "Recipe 3");
                    jButton2.setBackground(null);
                    jButton3.setBackground(null);
                    jButton4.setBackground(lightGreen);
                    jButton5.setBackground(null);
                } else if (calDiff4 <= calDiff2 && calDiff4 <= calDiff3 && calDiff4 <= calDiff1) {
                    barchartData.setValue(Rec1.calories, "Recipes", "Recipe 1");
                    barchartData.setValue(Rec2.calories, "Recipes", "Recipe 2");
                    barchartData.setValue(Rec3.calories, "Recipes", "Recipe 3");
                    barchartData.setValue(Rec4.calories, "Suggested Recipe", "Recipe 4");
                    jButton2.setBackground(null);
                    jButton3.setBackground(null);
                    jButton4.setBackground(null);
                    jButton5.setBackground(lightGreen);

                }

                JFreeChart barChart = ChartFactory.createBarChart("Best choice based on the given calories", "Recipes", "Calories", barchartData, PlotOrientation.VERTICAL, true, true, false);

                CategoryPlot barchrt = barChart.getCategoryPlot();
                barchrt.setRangeGridlinePaint(Color.ORANGE);
                ChartPanel barPanel = new ChartPanel(barChart);

                jPanel1.removeAll();
                jPanel1.add(barPanel, BorderLayout.CENTER);
                jPanel1.validate();

                mainFrame.setVisible(true);
            }
        });

        jLabel1.setText("500");

        jLabel3.setText("Calories:");

        SliderValue.setText("500");

        jButton1.setText("Home Page");
        jButton2.setText("Recipe1");
        jButton3.setText("Recipe2");
        jButton4.setText("Recipe3");
        jButton5.setText("Recipe4");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(mainFrame.getContentPane());
        mainFrame.getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
                layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addGroup(layout.createSequentialGroup()
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                                .addComponent(jLabel3)
                                                .addGroup(layout.createSequentialGroup()
                                                        .addComponent(jLabel1)
                                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                        .addComponent(jSlider2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 65, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addComponent(SliderValue))
                                        .addGap(0, 465, Short.MAX_VALUE))
                                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                        .addComponent(jButton1)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addComponent(jButton2)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addComponent(jButton3)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addComponent(jButton4)
                                        .addGap(18, 18, 18)
                                        .addComponent(jButton5)))
                        .addContainerGap())
        );
        layout.setVerticalGroup(
                layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addGap(86, 86, 86)
                        .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 468, Short.MAX_VALUE)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(jLabel3)
                                .addComponent(SliderValue))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                        .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(jLabel1))
                                .addComponent(jSlider2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(jButton1)
                                .addComponent(jButton5)
                                .addComponent(jButton4)
                                .addComponent(jButton2)
                                .addComponent(jButton3)))
        );
        mainFrame.setVisible(false);
        mainFrame.pack();
        
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            @Override
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mainFrame.dispose();
                FirstPanel f = new FirstPanel(Rec1,Rec2,Rec3,Rec4);
            }
        });
        
        

        jButton2.addActionListener(new java.awt.event.ActionListener() {
            @Override
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                if (rec1Guard == 0) {
                    for (int i = 1; i <= 8; i++) {
                        rec1Text.append("  " + Rec1.ingredients[i] + "\n");
                    }

                    rec1Text.setLineWrap(true);
                    rec1Text.setWrapStyleWord(true);

                    rec1Guard = 1;

                }
                rec1Dialog.setVisible(true);
            }
        });

        jButton3.addActionListener(new java.awt.event.ActionListener() {
            @Override
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                if (rec2Guard == 0) {
                    for (int i = 1; i <= 8; i++) {
                        rec2Text.append("  " + Rec2.ingredients[i] + "\n");
                    }

                    rec2Text.setLineWrap(true);
                    rec2Text.setWrapStyleWord(true);

                    rec2Guard = 1;

                }
                rec2Dialog.setVisible(true);
            }
        });

        jButton4.addActionListener(new java.awt.event.ActionListener() {
            @Override
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                if (rec3Guard == 0) {
                    for (int i = 1; i <= 11; i++) {
                        rec3Text.append("  " + Rec3.ingredients[i] + "\n");
                    }

                    rec3Text.setLineWrap(true);
                    rec3Text.setWrapStyleWord(true);

                    rec3Guard = 1;

                }
                rec3Dialog.setVisible(true);
            }
        });

        jButton5.addActionListener(new java.awt.event.ActionListener() {
            @Override
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                if (rec4Guard == 0) {
                    for (int i = 1; i <= 7; i++) {
                        rec4Text.append("  " + Rec4.ingredients[i] + "\n");
                    }

                    rec4Text.setLineWrap(true);
                    rec4Text.setWrapStyleWord(true);
                    rec4Guard = 1;
                }
                rec4Dialog.setVisible(true);

            }
        });

        go.addActionListener(new java.awt.event.ActionListener() {
            @Override
            public void actionPerformed(java.awt.event.ActionEvent evt) {

                int playerchoice = slide.getValue();
                jSlider2.setValue(slide.getValue());
                SliderValue.setText(String.valueOf(jSlider2.getValue()));

                int calDiff1 = Math.abs(slide.getValue() - Rec1.calories);
                int calDiff2 = Math.abs(slide.getValue() - Rec2.calories);
                int calDiff3 = Math.abs(slide.getValue() - Rec3.calories);
                int calDiff4 = Math.abs(slide.getValue() - Rec4.calories);

                DefaultCategoryDataset barchartData = new DefaultCategoryDataset();

                if (calDiff1 <= calDiff2 && calDiff1 <= calDiff3 && calDiff1 <= calDiff4) {
                    barchartData.setValue(Rec2.calories, "Recipes", "Recipe 2");
                    barchartData.setValue(Rec3.calories, "Recipes", "Recipe 3");
                    barchartData.setValue(Rec4.calories, "Recipes", "Recipe 4");
                    barchartData.setValue(Rec1.calories, "Suggested Recipe", "Recipe 1");
                    jButton2.setBackground(lightGreen);
                    jButton3.setBackground(null);
                    jButton4.setBackground(null);
                    jButton5.setBackground(null);
                } else if (calDiff2 <= calDiff1 && calDiff2 <= calDiff3 && calDiff2 <= calDiff4) {
                    barchartData.setValue(Rec1.calories, "Recipes", "Recipe 1");
                    barchartData.setValue(Rec3.calories, "Recipes", "Recipe 3");
                    barchartData.setValue(Rec4.calories, "Recipes", "Recipe 4");
                    barchartData.setValue(Rec2.calories, "Suggested Recipe", "Recipe 2");
                    jButton2.setBackground(null);
                    jButton3.setBackground(lightGreen);
                    jButton4.setBackground(null);
                    jButton5.setBackground(null);
                } else if (calDiff3 <= calDiff2 && calDiff3 <= calDiff1 && calDiff3 <= calDiff4) {
                    barchartData.setValue(Rec1.calories, "Recipes", "Recipe 1");
                    barchartData.setValue(Rec2.calories, "Recipes", "Recipe 2");
                    barchartData.setValue(Rec4.calories, "Recipes", "Recipe 4");
                    barchartData.setValue(Rec3.calories, "Suggested Recipe", "Recipe 3");
                    jButton2.setBackground(null);
                    jButton3.setBackground(null);
                    jButton4.setBackground(lightGreen);
                    jButton5.setBackground(null);
                } else if (calDiff4 <= calDiff2 && calDiff4 <= calDiff3 && calDiff4 <= calDiff1) {
                    barchartData.setValue(Rec1.calories, "Recipes", "Recipe 1");
                    barchartData.setValue(Rec2.calories, "Recipes", "Recipe 2");
                    barchartData.setValue(Rec3.calories, "Recipes", "Recipe 3");
                    barchartData.setValue(Rec4.calories, "Suggested Recipe", "Recipe 4");
                    jButton2.setBackground(null);
                    jButton3.setBackground(null);
                    jButton4.setBackground(null);
                    jButton5.setBackground(lightGreen);

                }

                JFreeChart barChart = ChartFactory.createBarChart("Best choice based on the given calories", "Recipes", "Calories", barchartData, PlotOrientation.VERTICAL, true, true, false);
                CategoryPlot barchrt = barChart.getCategoryPlot();
                barchrt.setRangeGridlinePaint(Color.ORANGE);

                ChartPanel barPanel = new ChartPanel(barChart);
                jPanel1.removeAll();
                jPanel1.add(barPanel, BorderLayout.CENTER);
                jPanel1.validate();

                Dimension dim = Toolkit.getDefaultToolkit().getScreenSize();
                mainFrame.setLocation(dim.width / 2 - mainFrame.getSize().width / 2, dim.height / 2 - mainFrame.getSize().height / 2);
                mainFrame.setVisible(true);
                fFrame.dispose();
            }
        });
    }

}
